# toyRobot-Jan2025
 Toy Robot challenge as at Jan 2025
 Challenge description: https://github.com/RafaelChefe/toy_robot

This is the January 2025 version of the Toy Robot challenge.
The project was created without reference to previous version(s) of this challenge.

There are 2 scripts in this version:
1. scriptMVP.js:
- Pure essential code, without any useful comments, or any consideration for readability
- This was to test how few lines it was possible to compress the program into

2. script.js:
- Normal script to run the toy robot, with descriptive comments for others/future me to understand why things were done
- Also some consideration for readability & user input consideration
