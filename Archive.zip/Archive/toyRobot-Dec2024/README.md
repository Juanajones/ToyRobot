JS Toy Robot challenge as at Dec 2024
